"""Integration checks for data isolation, exports and reference reproduction."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

from feature_selection import METHODS, compare_selection_schemes
from reproduce import compare_features, load_data


class SelectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = tempfile.TemporaryDirectory()
        cls.out = Path(cls.directory.name)
        cls.df = load_data()
        cls.comparison = compare_selection_schemes(cls.df, cls.out)
        cls.protocol = json.loads((cls.out / 'selection_protocol.json').read_text())

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

    def test_shared_holdout_is_excluded_from_all_cv_folds(self):
        training = set(self.protocol['train_rows'])
        holdout = set(self.protocol['test_rows'])
        self.assertEqual((len(training), len(holdout)), (40, 10))
        self.assertFalse(training & holdout)
        all_validation = []
        for fold in self.protocol['folds']:
            train, validation = set(fold['train_rows']), set(fold['validation_rows'])
            self.assertEqual(train | validation, training)
            self.assertFalse(train & validation)
            self.assertEqual((len(train), len(validation)), (32, 8))
            all_validation.extend(validation)
        self.assertEqual(len(all_validation), len(set(all_validation)))
        history = pd.read_csv(self.out / 'selection_cv_history.csv')
        exhaustive = history[history.method == 'Exhaustive']
        self.assertEqual(len(exhaustive), 31)
        self.assertEqual(exhaustive.features.nunique(), 31)
        self.assertEqual(exhaustive.n_features.value_counts().to_dict(),
                         {1: 5, 2: 10, 3: 10, 4: 5, 5: 1})
        self.assertEqual(set(self.comparison.method), set(METHODS))
        for method in METHODS:
            chosen = history[(history.method == method) & history.chosen]
            self.assertEqual(len(chosen), 1)
            score = self.comparison.set_index('method').loc[method, 'cv_rmse']
            self.assertAlmostEqual(chosen.cv_rmse.iloc[0], score)

    def test_exports_reconstruct_actual_model_predictions_and_metrics(self):
        predictions = pd.read_csv(self.out / 'selection_predictions.csv')
        models = json.loads((self.out / 'selection_models.json').read_text())
        for row in self.comparison.itertuples():
            pred = predictions[predictions.method == row.method]
            self.assertEqual(set(pred.row_id), set(self.protocol['test_rows']))
            self.assertEqual(len(pred), 10)
            self.assertAlmostEqual(np.sqrt(mean_squared_error(
                pred.actual_profit, pred.predicted_profit)), row.test_rmse)
            self.assertAlmostEqual(r2_score(pred.actual_profit, pred.predicted_profit),
                                   row.test_r_squared)
            # Reconstruct exported predictions independently, in original units.
            details = models[row.method]
            data = self.df.loc[pred.row_id]
            value = np.full(len(data), details['raw_intercept'])
            for feature, coef in details['raw_coefficients'].items():
                if feature.startswith('State_'):
                    x = data.State.eq(feature.removeprefix('State_')).astype(float)
                else:
                    x = data[feature]
                value += x.to_numpy() * coef
            np.testing.assert_allclose(value, pred.predicted_profit, rtol=1e-10)
            self.assertEqual(row.n_features, len(details['selected_features']))
        self.assertEqual(models['Lasso']['selected_features'],
                         [f for f, c in models['Lasso']['scaled_coefficients'].items() if c != 0])

    def test_holdout_outcomes_cannot_change_selection_or_scaling(self):
        changed = self.df.copy()
        changed.loc[self.protocol['test_rows'], 'Profit'] += 1000000
        fit_sizes = []

        class TrackingScaler(StandardScaler):
            def fit(self, X, y=None, sample_weight=None):
                fit_sizes.append(len(X))
                return super().fit(X, y, sample_weight=sample_weight)

        with tempfile.TemporaryDirectory() as directory:
            with patch('feature_selection.StandardScaler', TrackingScaler):
                result = compare_selection_schemes(changed, directory)
            pd.testing.assert_frame_equal(
                self.comparison.drop(columns=['test_rmse', 'test_r_squared']),
                result.drop(columns=['test_rmse', 'test_r_squared']))
            self.assertEqual(json.loads((Path(directory) / 'selection_models.json').read_text()),
                             json.loads((self.out / 'selection_models.json').read_text()))
            self.assertTrue((result.test_rmse > self.comparison.test_rmse).all())
            curve_columns = ['method', 'n_features', 'features', 'cv_rmse', 'cv_rmse_std', 'alpha', 'chosen']
            pd.testing.assert_frame_equal(
                pd.read_csv(self.out / 'selection_feature_curves.csv')[curve_columns],
                pd.read_csv(Path(directory) / 'selection_feature_curves.csv')[curve_columns])
        self.assertEqual(set(fit_sizes), {32, 40})

    def test_per_method_feature_curves_have_real_matching_predictions(self):
        curves = pd.read_csv(self.out / 'selection_feature_curves.csv')
        predictions = pd.read_csv(self.out / 'selection_curve_predictions.csv')
        for method in METHODS:
            subset = curves[curves.method == method]
            self.assertEqual(subset.n_features.nunique(), len(subset))
            chosen = subset[subset.chosen]
            self.assertEqual(len(chosen), 1)
            final = self.comparison.set_index('method').loc[method]
            self.assertEqual(chosen.features.iloc[0], final.features)
            for name in ['test_rmse', 'test_r_squared', 'cv_rmse']:
                self.assertAlmostEqual(chosen[name].iloc[0], final[name])
        for row in curves.itertuples():
            pred = predictions[(predictions.method == row.method) &
                               (predictions.n_features == row.n_features)]
            self.assertEqual(len(pred), 10)
            self.assertEqual(set(pred.row_id), set(self.protocol['test_rows']))
            self.assertAlmostEqual(np.sqrt(mean_squared_error(
                pred.actual_profit, pred.predicted_profit)), row.test_rmse)
            self.assertAlmostEqual(r2_score(pred.actual_profit, pred.predicted_profit),
                                   row.test_r_squared)
        rf_three = curves[(curves.method == 'RFECV') & (curves.n_features == 3)].iloc[0]
        self.assertIn('Administration', rf_three.features)
        self.assertNotAlmostEqual(rf_three.test_rmse, 8309.059683, places=2)
        self.assertNotIn(4, curves[curves.method == 'Lasso'].n_features.tolist())

    def test_original_image_metrics_are_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            metrics = compare_features(self.df, directory)
        np.testing.assert_allclose(metrics.RMSE,
            [8274.868018, 8198.797191, 8309.059683, 8409.916714, 9137.990153], atol=0.001)
        np.testing.assert_allclose(metrics.R_squared,
            [0.94645876, 0.94743864, 0.94601538, 0.94469688, 0.93470685], atol=1e-7)


if __name__ == '__main__':
    unittest.main()
