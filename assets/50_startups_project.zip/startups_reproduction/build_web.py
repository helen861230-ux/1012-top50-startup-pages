"""Export verified Python outputs into a dependency-free interactive web dashboard."""
from pathlib import Path
import json
import shutil
import zipfile
import argparse
import pandas as pd

ROOT = Path(__file__).resolve().parent
DIST = ROOT / 'web' / 'dist'

def records(path):
    # pandas emits non-finite values as null, keeping generated JavaScript valid.
    return json.loads(pd.read_csv(path).to_json(orient='records'))

def build_web(github_pages=False):
    from reproduce import format_results_table
    DIST.mkdir(parents=True, exist_ok=True)
    assets = DIST / 'assets'
    assets.mkdir(exist_ok=True)
    for name in ['index.html', 'styles.css', 'app.js']:
        shutil.copy2(ROOT / 'web' / name, DIST / name)
    data = {'dataset': records(ROOT / 'data/50_Startups.csv'),
            'reference': records(ROOT / 'results/metrics.csv'),
            'selection': records(ROOT / 'results/selection_comparison.csv'),
            'curves': records(ROOT / 'results/selection_feature_curves.csv'),
            'history': records(ROOT / 'results/selection_cv_history.csv'),
            'predictions': records(ROOT / 'results/selection_predictions.csv'),
            'ols': records(ROOT / 'results/ols_metrics.csv'),
            'influence': records(ROOT / 'results/influence.csv'),
            'models': json.loads((ROOT / 'results/selection_models.json').read_text()),
            'protocol': json.loads((ROOT / 'results/selection_protocol.json').read_text()),
            'markdown': {}, 'source': {}}
    for key, filename, result_file in [
        ('reference', 'metrics.csv', 'feature_results.md'),
        ('selection', 'selection_comparison.csv', 'selection_results.md')]:
        content = format_results_table(pd.read_csv(ROOT / 'results' / filename)) + '\n'
        (ROOT / 'results' / result_file).write_text(content)
        data['markdown'][key] = content
    for name in ['reproduce.py', 'feature_selection.py', 'requirements.txt', 'build_web.py']:
        data['source'][name] = (ROOT / name).read_text()
    (DIST / 'data.js').write_text('window.STARTUP_DATA = ' + json.dumps(data, ensure_ascii=False, allow_nan=False) + ';\n')
    for p in (ROOT / 'results').iterdir():
        if p.is_file(): shutil.copy2(p, assets / p.name)
    shutil.copy2(ROOT / 'data/50_Startups.csv', assets / '50_Startups.csv')
    for name in ['50_startups_reproduction.ipynb', 'reproduce.py', 'feature_selection.py', 'requirements.txt']:
        shutil.copy2(ROOT / name, assets / name)
    (assets / 'ols_summary.txt').write_text((ROOT / 'results/ols_summary.txt').read_text())
    files = [ROOT / n for n in ['README.md', 'reproduce.py', 'feature_selection.py',
             'requirements.txt', 'build_web.py', 'provenance.json', '50_startups_reproduction.ipynb']]
    for folder in ['data', 'results', 'tests']:
        files += [p for p in (ROOT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    files += [ROOT / 'web' / name for name in ['index.html', 'app.js', 'styles.css']]
    with zipfile.ZipFile(assets / '50_startups_project.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for p in files: z.write(p, Path('startups_reproduction') / p.relative_to(ROOT))
    print(f'Web export complete: {DIST}')
    if github_pages:
        pages = ROOT / 'docs'
        shutil.copytree(DIST, pages, dirs_exist_ok=True)
        for name in ['index.html', 'app.js']:
            path = pages / name
            path.write_text(path.read_text().replace(
                'https://github.com/helen861230-ux/1012-top50-startup-',
                'https://github.com/helen861230-ux/1012-top50-startup-pages'))
        # Serve generated static files directly, without a Jekyll transform.
        (pages / '.nojekyll').write_text('')
        print(f'GitHub Pages export complete: {pages}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--github-pages', action='store_true',
                        help='Also export the static site to docs/ for GitHub Pages')
    build_web(github_pages=parser.parse_args().github_pages)
