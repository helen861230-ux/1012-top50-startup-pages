# 50 Startups 線性迴歸專案重現

本專案包含中文 Notebook、可獨立執行的 Python 程式、完整 CSV 與已計算的結果，並實作五種自動特徵選擇方法。

![RMSE and R-squared by Number of Features](results/feature_comparison.png)

## 執行方式

建議 Python 3.12。在本資料夾開啟終端機：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python reproduce.py
```

Windows 啟用環境：`.venv\Scripts\activate`。

Notebook 可上傳 Google Colab，並將 `reproduce.py`、`feature_selection.py` 與 `data/50_Startups.csv` 放在同一工作目錄下的相應位置，再安裝 requirements。也可用本機 Jupyter 開啟 `50_startups_reproduction.ipynb`，選擇已安裝套件的 Python kernel。交付 Notebook 已執行並保留圖與輸出。終端機使用 `print()` 顯示 Markdown 原文，Notebook 使用 `display(Markdown(...))` 顯示表格。

## 網頁版

公開網頁（GitHub Pages）：https://helen861230-ux.github.io/1012-top50-startup-pages/

公開網站儲存庫：https://github.com/helen861230-ux/1012-top50-startup-pages

原始儲存庫保持私人。原 ChatGPT Sites 網址仍保留：https://fifty-startups-regression-lab.beigelily66.chatgpt.site （僅擁有者可存取）。

包含總覽、五種特徵選擇、資料探索與 One-Hot 顯示、利潤預測、OLS 診斷、程式與下載六個頁面。Markdown 表格由 Python `tabulate` 產生，可在頁面複製或下載。

網頁展示已執行的 Python 結果；輸入條件的預測使用匯出的原單位係數即時計算，不會在瀏覽器重新訓練。更新訓練結果並建立網頁：

```bash
python reproduce.py
python build_web.py
python -m http.server 8000 --directory web/dist
```

開啟 http://localhost:8000。也可直接開啟 `web/dist/index.html`；網站不需要外部 JavaScript CDN，檢視資料與預測不會把輸入傳送到外部服務。`web/` 是網頁原始碼，`web/dist/` 是可直接發布的靜態輸出。網站下載的 ZIP 包含完整 Python 專案與網頁原始碼。

### GitHub Pages 發布檔

產生適用於 GitHub Pages 的靜態網站：

```bash
python build_web.py --github-pages
```

輸出到 `docs/`，包含 `.nojekyll`。將 `docs/` 的內容同步到公開網站儲存庫 `1012-top50-startup-pages` 的根目錄；該儲存庫的 Settings → Pages 使用「Deploy from a branch」、`main` 分支與 `/ (root)`。網站內全部資源採相對路徑，可使用 GitHub Pages 的專案子路徑。

`docs/` 是自動生成的發布檔；修改網頁原始碼後請重新執行匯出。若 GitHub 方案不支援私人儲存庫的 Pages，必須使用支援的付費方案或公開的網站儲存庫。發布狀態以 GitHub Pages 設定與建置結果為準。

### 特徵數量曲線的連動

總覽的「特徵數量與模型表現」預設隨目前方法更新，點選資料點也會同步更新上方四個指標卡與右側特徵。切換方法會回到該方法由 CV 選定的模型，亦可按「回到 CV 選定模型」。原附圖另設「原附圖」分頁，明確標示固定順序且無 CV 分數。

- Exhaustive：每個特徵數選訓練 CV 最佳組合。
- Forward／Backward：使用各自的逐步路徑。
- RFECV：以完整訓練集上的 RFE 產生各特徵數模型，CV 分數沿用折內的 RFE 路徑。
- Lasso：依完整訓練集的非零係數數量分組，各組以 CV 選 alpha。此網格未產生 4 個特徵的模型，故不補造資料點，也不畫線跨過缺失的特徵數。

候選模型全部在讀取測試目標前決定。曲線的測試分數只作描述，不用來挑方法或特徵數。Exhaustive、Forward、Backward 選到相同路徑，所以這三條曲線數值相同是正常結果。

`results/selection_feature_curves.csv` 提供各方法的曲線與選定標記，`selection_curve_predictions.csv` 提供逐筆預測，可獨立重算每個點的測試 RMSE 與 R²。

## 五種自動特徵選擇（2026-10-19 新增）

`python reproduce.py` 會同時執行以下五種方法；原本的附圖重現與 OLS 分析也會保留。

|方法|實作與選擇規則|
|---|---|
|Exhaustive／Best Subset|搜尋全部 31 個非空組合，以 CV 平均 RMSE 選擇|
|Forward Selection|逐步搜尋最佳新增欄位，走完所有大小，再選路徑上 CV 最佳組合|
|Backward Elimination|從全特徵逐步刪除欄位，再選路徑上 CV 最佳組合|
|RFECV|以標準化 OLS 係數逐步刪除，交叉驗證決定特徵數|
|Lasso Selection|Pipeline + GridSearchCV 選 alpha，非零係數決定特徵；保留正則化模型作最終預測|

**評估設定：** 使用與原附圖相同的 40／10 切分（random_state=0）。只在 40 筆訓練內做 5-fold CV（shuffle=True、random_state=42），各方法共用相同 folds，以各折 RMSE 的算術平均作選擇標準。StandardScaler 放在 Pipeline，每折僅 fit 該折訓練資料，RFECV 的每次遞迴亦同。Lasso alpha 使用 `np.logspace(-1, 5, 61)`；Profit 維持原始單位。

State 的兩個 dummy 各自參與篩選，California 仍由兩欄皆為 0 表示。Forward／Backward 以 CV 評分新增／刪除，不使用 p-value 門檻。前四種方法的最終模型為 OLS，Lasso 的最終模型仍是 Lasso，沒有在選特徵後改用 OLS。

|方法|選定特徵|平均 CV RMSE|測試 RMSE|測試 R²|
|---|---|---:|---:|---:|
|Backward|R&D Spend、Marketing Spend、State_Florida|8825.16|8376.45|0.945136|
|Exhaustive|R&D Spend、Marketing Spend、State_Florida|8825.16|8376.45|0.945136|
|Forward|R&D Spend、Marketing Spend、State_Florida|8825.16|8376.45|0.945136|
|Lasso|R&D Spend、Marketing Spend|8831.08|8425.66|0.944490|
|RFECV|R&D Spend、Marketing Spend|8862.79|8198.80|0.947439|

表格依訓練 CV RMSE 排序，不依測試分數選方法。RFECV 與 Lasso 都選到兩欄，但 Lasso 係數有收縮，所以最終預測不同。RFECV 各折重新選欄位，其 CV 分數與固定兩欄的分數也不一定相同。Lasso 本次選定 alpha 約 1584.8932。

![Five automatic feature selection schemes](results/selection_comparison.png)

誤差棒是五折 RMSE 的標準差，不是信賴區間。這些 CV 分數用於選擇，未使用外層 nested CV；原 10 筆測試資料已在附圖重現時看過，不是全新的獨立驗證資料。程式不使用測試分數挑選組合、alpha 或方法。

### 新增輸出與驗證

- `feature_selection.py`：五種方法與共用資料切分、fold 內標準化。
- `results/selection_comparison.csv`：選定特徵數、欄位、CV 與測試指標。
- `results/selection_results.md`：以 `tabulate` 產生的五種方法 Markdown 表格，包含 Method、Number of Features、Selected Features、RMSE、R-squared。RMSE 與 R-squared 是測試集指標，分別顯示 2 與 6 位小數。
- `results/feature_results.md`：原附圖 1～5 特徵實驗的相同格式表格，不含 Method 欄位。
- `results/selection_cv_history.csv`：全部候選評分、每折 RMSE、Lasso alpha 搜尋紀錄。
- `results/selection_predictions.csv`：各方法對相同 10 筆測試列的預測。
- `results/selection_models.json`：最終特徵、標準化參數、係數及原單位截距，可獨立還原預測。
- `results/selection_protocol.json`：切分列號、各折 train/validation 列號、搜尋設定、Forward／Backward 路徑與 RFECV 各折欄位。
- `tests/test_feature_selection.py`：驗證測試目標改動不影響選擇、scaler 僅 fit 32／40 筆、輸出預測與指標可重建，以及原附圖指標不變。

```bash
python -m unittest discover -s tests -v
```

## 附圖的重現設定

- 資料：原 Kaggle Notebook 引用的 50_Startups.csv，50 筆、5 欄，無缺漏或重複列。
- 預測目標：Profit，維持原始單位。
- 模型：LinearRegression，含截距。
- 切分：test_size=0.2、random_state=0、shuffle=True；40 筆訓練、10 筆測試。
- 編碼：State 採 one-hot，California 為參考類別，產生 Florida、New York 兩個 dummy。
- 特徵順序：R&D Spend → Marketing Spend → State_New York → State_Florida → Administration，每次使用前 k 個欄位。
- 不刪除資料、不標準化測試實驗的目標；每個模型使用完全相同的切分。

|特徵數|本次新增欄位|測試 RMSE|測試 R²|
|---:|---|---:|---:|
|1|R&D Spend|8274.8680|0.946459|
|2|Marketing Spend|8198.7972|0.947439|
|3|State_New York|8309.0597|0.946015|
|4|State_Florida|8409.9167|0.944697|
|5|Administration|9137.9902|0.934707|

五個點的趨勢與附圖一致；兩特徵的測試 RMSE 最低。上述數值全部由模型預測計算，沒有使用圖片讀值代替運算。圖片沒有提供精確數字或程式碼，因此這是符合圖片的可重現設定，無法證明與圖片作者使用的程序完全相同。特徵順序是根據圖形核對出的明確設定，並非已知的自動選擇方法。

因為使用單次 10 筆測試資料、且重現設定經圖片核對，不能把結果當成新資料的無偏效能估計；正式模型應在訓練集內做交叉驗證，再以獨立資料評估。

## 與原 Kaggle 專案的對應

原版進行 EDA、州別 dummy、StandardScaler、statsmodels OLS、單變數／研發與行銷雙變數比較、殘差 Q-Q、殘差散點與 Cook's distance，最後刪除第 49 列再建立研發單變數模型。它沒有附圖的 1～5 特徵測試比較。

此版保留核心 OLS 分析與診斷，另外加入指定圖片實驗。OLS 的指標在 `ols_metrics.csv`，是全資料擬合指標，與 `metrics.csv` 的測試指標分開。

原版同時加入三個州 dummy 與截距會完全共線；此版省略 California，擬合空間與 R² 相同。原版標準化後直接以 RD=100000 預測會混用尺度；此版先轉換輸入並將預測還原到原始 Profit 單位。第 49 列的移除僅存在於原版 OLS 重現流程，圖片實驗仍使用完整 50 筆。

## 檔案

- `50_startups_reproduction.ipynb`：中文解說、執行結果與圖。
- `reproduce.py`：資料驗證、特徵比較、OLS、繪圖與輸出。
- `data/50_Startups.csv`：原資料。
- `results/feature_comparison.png`：對應附圖的並排曲線。
- `results/metrics.csv`、`predictions.csv`：各模型測試指標與逐列預測。
- `results/split.json`、`coefficients.json`：切分列號與係數。
- `results/ols_summary.txt`、`ols_metrics.csv`、`influence.csv`、`ols_diagnostics.png`：原版分析重現。
- `results/example_prediction.json`：研發支出 100000 的原單位預測。
- `provenance.json`：資料與原 Notebook 來源、版本、CSV SHA256。

## 來源

原作者：Akash Singh。原 Notebook：
https://www.kaggle.com/code/akash17/50-startups-linearregression

原資料集：
https://www.kaggle.com/datasets/karthickveerakumar/startup-logistic-regression

下載方法：Kaggle 公開 kernel pull 與 dataset download API。亦比對 GitHub 的同名資料，50 筆內容一致：
https://github.com/Avik-Jain/100-Days-Of-ML-Code/blob/master/datasets/50_Startups.csv

本專案為依來源重新實作與擴充，並未將原 Notebook 的輸出當作本次模型結果。
